package aviation;

import java.util.Arrays;
import java.util.LinkedHashMap;

public class Pilot implements Cloneable {
    private String name;
    private double[] flightHours;
    public Pilot(String name,double[] flightHours){
        this.name = name;
        this.flightHours = Arrays.copyOf(flightHours,flightHours.length);
    }
    public String getName(){
        return name;
    }
    public double[] getFlightHours(){
        return Arrays.copyOf(flightHours,flightHours.length);
    }
    public void setName(){
        this.name = name;
    }
    public void setFlightHours(){
        this.flightHours = Arrays.copyOf(flightHours,flightHours.length);
    }
    public void changeFlingHours(int index,double newHours){
        if(index>=0 && index<flightHours.length){
            flightHours[index] = newHours;
        }
    }
    @Override
    public Object clone() throws CloneNotSupportedException{
        Pilot klonowanyPilot = (Pilot) super.clone();
        klonowanyPilot.flightHours = Arrays.copyOf(this.flightHours,this.flightHours.length);
        return klonowanyPilot;
    }
}
