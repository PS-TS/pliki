package aviation;

import java.util.ArrayList;
import java.util.Arrays;

public class TestPilot {
    public static void main(String[] args){
        double[] lista = {20.0,30.0,40.0,50.0,60.0};
        Pilot pilot = new Pilot("Szeryf",lista);
        try{
            Pilot pilotKlon = (Pilot) pilot.clone();
            System.out.println("Oryginalny pilot " + pilot.getName() + " Godziny lotu " + Arrays.toString(pilot.getFlightHours()));
            System.out.println("Sklonowany pilot " + pilotKlon.getName() + " godziny lotu " + Arrays.toString(pilotKlon.getFlightHours()));
            pilotKlon.changeFlingHours(2,15.0);
            System.out.println("Oryginalny pilot (NIE ZMIENIL CZASU) " + pilot.getName() + " Godziny lotu " + Arrays.toString(pilot.getFlightHours()));
            System.out.println("Sklonowany pilot po zmianie lotu trzeciego " + pilotKlon.getName() + " godziny lotu " + Arrays.toString(pilotKlon.getFlightHours()));
        } catch (CloneNotSupportedException e) {
            throw new RuntimeException(e);
        }
    }
}
