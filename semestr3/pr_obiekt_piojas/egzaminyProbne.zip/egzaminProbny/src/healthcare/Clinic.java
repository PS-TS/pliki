package healthcare;

import javax.annotation.processing.SupportedOptions;
import java.util.Objects;

public class Clinic extends Hospital {
    double rating;
    public Clinic(String name, double capacity,double rating) {
        super(name, capacity);
        if(rating<0.0 || rating > 5.0){
            this.rating =3.0;
        }
        else this.rating = rating;
    }
    public double getRating(){
        return rating;
    }
    public void setRating(double rating){
        if(rating<0.0 || rating > 5.0){
            this.rating =3.0;
        }
        else this.rating = rating;
    }
    @Override
    public String toString(){
        return this.getClass().getName() + getName() + getCapacity() + rating;
    }
    @Override
    public boolean equals(Object o){
        if(this == o) return true;
        if(o == null || getClass()!= o.getClass()) return false;
        if(!super.equals(o)) return false;
        Clinic clinic = (Clinic)o;
        return Objects.equals(clinic.rating,rating);
    }
    @Override
    public int hashCode(){
        return Objects.hash(super.hashCode(),rating);
    }
}
