package healthcare;

public class TestHospital {
    public static void main(String[] args) {
        Hospital hospital = new Hospital("Onkologia",200.0);
        Hospital hospital2 = new Hospital("Onkologia",200.0);
        Hospital hospital3 = new Hospital("Onkologia",200.0);
        Clinic clinic = new Clinic("Frajerzy",51.0,3.3);
        Clinic clinic2 = new Clinic("Frajerzy",51.0,3.3);
        hospital.getName();
        System.out.println(hospital);
        hospital.setName("lamusy");

        System.out.println(clinic.equals(clinic2));
    }
}