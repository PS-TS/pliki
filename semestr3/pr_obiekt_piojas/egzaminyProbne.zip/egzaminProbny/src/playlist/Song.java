package playlist;

public class Song {
    private String tittle;
    private String artist;
    int duration;
    public Song(String tittle, String artist, int duration){
        this.tittle = tittle;
        this.artist = artist;
        this.duration = duration;
    }
    public String getTittle(){
        return tittle;
    }
    public String getArtist(){
        return artist;
    }
    public int getDuration(){
        return duration;
    }
    public String toString(){
        return "Tytul " + tittle + " Autor " + artist + " Czas trwania " + duration;
    }
}
