package playlist;

import java.util.Comparator;

public class ArtistTitleComparator implements Comparator<Song> {
    @Override
    public int compare(Song o1, Song o2) {
        int cos = o1.getArtist().compareTo(o2.getArtist());
        if(cos !=0){
            return cos;
        }
        else return o1.getTittle().compareTo(o2.getTittle());
    }
}
