package playlist;

import java.util.Arrays;

public class Test {
    public static void main(String[] args){
        Song[] songs = new Song[5];
        songs[0] = new Song("Szpaku","Siema",20);
        songs[1] = new Song("W pustyni 1","mickiewicz1",21);
        songs[2] = new Song("W pustyni 2","mickiewicz2",22);
        songs[3] = new Song("W pustyni 3","mickiewicz3",23);
        songs[4] = new Song("W pustyni 4","mickiewicz4",24);
        Arrays.sort(songs,new DurationComparator().thenComparing(new ArtistTitleComparator()));
        for(Song song : songs){
            System.out.println(song);
        }
    }
}
