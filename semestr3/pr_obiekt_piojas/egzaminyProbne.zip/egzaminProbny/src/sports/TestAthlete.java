package sports;

import java.util.Arrays;

public class TestAthlete {
    public static void main(String[] args){
        Athlete[] athletes = new Athlete[4];
        athletes[0] = new Athlete("Wladek", "Polska",50.5);
        athletes[1] = new Athlete("Slawek", "Czechy",10.4);
        athletes[2] = new Athlete("Mirek", "Albania",40.2);
        athletes[3] = new Athlete("Czesiek", "USA",35.0);
        Arrays.sort(athletes,new RecordComparator().thenComparing(new NationalityNameComparator()));
        for(Athlete athlete : athletes){
            System.out.println(athlete);
        }
    }
}
