package sports;

public class Athlete {
    private String name;
    private String nationality;
    double records;
    public Athlete(String name,String nationality, double records){
        this.name = name;
        this.nationality = nationality;
        this.records = records;
    }
    public String getName(){
        return name;
    }
    public String getNationality(){
        return nationality;
    }
    public Double getRecords(){
        return records;
    }
    public String toString(){
        return "Klasa " + this.getClass().getName() + " Imie " + name + " Narodowosc " + nationality + " rekord " + records;
    }
}
