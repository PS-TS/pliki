package music;

import java.util.Arrays;
import java.util.ArrayList;
import java.util.Objects;

public class MusicStore {
    private String name;
    private String city;
    private ArrayList<String> albums;
    public MusicStore(String name,String city,ArrayList<String> albums){
        this.name = name;
        this.city = city;
        this.albums = new ArrayList<>(albums);
    }
    public void addAlbum(String album){
        albums.add(album);
    }
    public void removeAlbum(String album){
        albums.remove(album);
    }
    public String getName(){
        return name;
    }
    public String getCity(){
        return city;
    }
    public ArrayList<String> getAlbums(){
        return new ArrayList<>(albums);
    }
    public void setName(String name){
        this.name = name;
    }
    public void setCity(String city){
        this.city = city;
    }
    public void setAlbums(ArrayList<String> albums){
        this.albums = new ArrayList<>(albums);
    }
    @Override
    public String toString(){
        return "Klasa "+ this.getClass().getName() + " Nazwa " + name + " Miasto " + city + " Album " + albums;
    }
    @Override
    public boolean equals(Object o){
        if(this == o) return true;
        if(o == null || getClass() != o.getClass()) return false;
        MusicStore musicStore = (MusicStore) o;
        return Objects.equals(musicStore.name,name) &&
                Objects.equals(musicStore.city,city) &&
                Objects.equals(musicStore.albums,albums);
    }
    @Override
    public int hashCode(){
        return Objects.hash(name,city,albums);
    }
}
