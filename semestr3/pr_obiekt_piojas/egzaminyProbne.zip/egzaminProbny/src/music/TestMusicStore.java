package music;

import java.util.ArrayList;

public class TestMusicStore {
    public static void main(String[] args){
        ArrayList<String>albumsList = new ArrayList<>();
        albumsList.add("Album1");
        albumsList.add("Album2");
        ArrayList<String>albumsList2 = new ArrayList<>();
        albumsList2.add("Album3");
        albumsList2.add("Album4");
        MusicStore musicStore = new MusicStore("Maciek", "Olsztyn", albumsList);
        VinylStore vinylStore = new VinylStore("Slawek", "Wawa", albumsList2,20);
        System.out.println(musicStore);
        musicStore.addAlbum("Album3");
        System.out.println(musicStore);
        musicStore.removeAlbum("Album3");
        System.out.println(musicStore);
        musicStore.removeAlbum("Album2");
        System.out.println(musicStore);
    }
}
