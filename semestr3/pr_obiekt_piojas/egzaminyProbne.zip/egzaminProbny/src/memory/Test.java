package memory;

public class Test {
    public static void main(String[] args){
        RAMManager ramManager = new RAMManager();
        DiskManager diskManager = new DiskManager();
        ramManager.allocateMemory(20);
        ramManager.freeMemory();
        String cos = MemoryManager.getmemoryType();
        System.out.println(cos);
    }
}
