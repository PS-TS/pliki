namespace lab4
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }


        int[] convert()
        {
            String liczbyTxt = textBox1.Text;
            var liczbyStr = liczbyTxt.Trim().Split(' ');
            int[] liczby = new int[liczbyStr.Length];

            for (int i = 0; i < liczbyStr.Length; i++)
            {
                liczby[i] = int.Parse(liczbyStr[i]);
            }
            return liczby;
        }


        void bubbleSortMinMax(int[] liczby)
        {
            int temp = 0;
            bool czyZmiana;

            do
            {
                czyZmiana = false;
                for (int i = 0; i < liczby.Length - 1; i++)
                {
                    if (liczby[i] > liczby[i + 1])
                    {
                        czyZmiana = true;
                        temp = liczby[i];
                        liczby[i] = liczby[i + 1];
                        liczby[i + 1] = temp;
                    }
                }
            } while (czyZmiana == true);
        }


        void bubbleSortMaxMin(int[] liczby)
        {
            int temp = 0;
            bool czyZmiana;

            do
            {
                czyZmiana = false;
                for (int i = 0; i < liczby.Length - 1; i++)
                {
                    if (liczby[i + 1] > liczby[i])
                    {
                        czyZmiana = true;
                        temp = liczby[i];
                        liczby[i] = liczby[i + 1];
                        liczby[i + 1] = temp;
                    }
                }
            } while (czyZmiana == true);
        }


        void selectSort(int[] liczby)
        {
            int min, temp;

            for (int i = 0; i < liczby.Length - 1; i++)
            {
                min = i;
                for (int j = i + 1; j < liczby.Length; j++)
                {
                    if (liczby[j] < liczby[min])
                    {
                        min = j;
                    }
                }
                temp = liczby[i];
                liczby[i] = liczby[min];
                liczby[min] = temp;
            }
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            int[] liczby = convert();
            bubbleSortMinMax(liczby);
            String napis = String.Join(' ', liczby);
            label1.Text = "BubbleSort, rosn�co: " + napis;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            int[] liczby = convert();
            bubbleSortMaxMin(liczby);
            String napis = String.Join(' ', liczby);
            label1.Text = "BubbleSort, malej�co: " + napis;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            int[] liczby = convert();
            selectSort(liczby);
            String napis = String.Join(' ', liczby);
            label1.Text = "SelectSort, rosn�co: " + napis;
        }
    }
}