using System.Diagnostics.Contracts;
using System.Xml.Linq;

namespace lab5
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            var w1 = new WezelBFS(5);
            var w2 = new WezelBFS(1);
            var w3 = new WezelBFS(2);
            var w4 = new WezelBFS(3);
            var w5 = new WezelBFS(8);
            var w6 = new WezelBFS(4);
            w1.sasiedzi.Add(w2);
            w2.sasiedzi.Add(w4);
            w2.sasiedzi.Add(w5);
            w4.sasiedzi.Add(w6);
            w6.sasiedzi.Add(w3);
            w5.sasiedzi.Add(w3);
            A(w1);

        }

        //Przeszukiwanie wszerz
        List<WezelBFS> kolejka = new List<WezelBFS>();
        List<WezelBFS> odwiedzone = new List<WezelBFS>();
        void A(WezelBFS w)
        {
            odwiedzone.Add(w);
            MessageBox.Show(w.wartosc.ToString());

            foreach (var sasiad in w.sasiedzi)
            {
                if (!odwiedzone.Contains(sasiad) && !kolejka.Contains(sasiad))
                {
                    kolejka.Add(sasiad);

                }
            }

            if (kolejka.Count > 0)
            {
                WezelBFS nastepnyWezel = kolejka[0];
                kolejka.Remove(nastepnyWezel);
                A(nastepnyWezel);
            }
        }
    }



    //BFS - przeszukiwanie wszerz
    public class WezelBFS
    {
        public int wartosc;
        public List<WezelBFS> sasiedzi = new List<WezelBFS>();

        public WezelBFS(int liczba)
        {
            this.wartosc = liczba;
        }
    }
}