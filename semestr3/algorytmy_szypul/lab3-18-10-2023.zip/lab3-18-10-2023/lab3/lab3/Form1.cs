namespace lab3
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            bubble_sort();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }


        private void bubble_sort()
        {
            int[] liczby = { 9, 7, 1, 8 };
            int temp = 0;
            bool czyZmiana;

            do
            {
                czyZmiana = false;
                for (int i = 0; i < liczby.Length - 1; i++)
                {
                    if (liczby[i] > liczby[i + 1])
                    {
                        czyZmiana = true;
                        temp = liczby[i];
                        liczby[i] = liczby[i + 1];
                        liczby[i + 1] = temp;
                    }
                }
            } while (czyZmiana == true);


            string tekst = string.Join(',', liczby);
            label1.Text = tekst;
        }


        private void select_sort()
        {
            int[] liczby = { 9, 7, 1, 8 };
            int min, temp, j;

            for(int i = 0; i < liczby.Length - 1 ; i++)
            {
                min = i;

                for(j = i + 1; j < liczby.Length; j++)
                {
                    if (liczby[j] < liczby[min])
                    {
                        min = j;
                    }
                }
                temp = liczby[i];
                liczby[i] = liczby[min];
                liczby[min] = temp;
            }

            string tekst = string.Join(',', liczby);
            label2.Text = tekst;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            select_sort();
        }
    }
}