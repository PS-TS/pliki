using System.Diagnostics.Contracts;
using System.Xml.Linq;

namespace lab5
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            var w1 = new Wezel(5);
            var w2 = new Wezel(4);
            var w3 = new Wezel(2);
            var w4 = new Wezel(3);
            var w5 = new Wezel(8);
            var w6 = new Wezel(4);
            var w7 = new Wezel(11);
            var w8 = new Wezel(9);
            var w9 = new Wezel(15);
            var w10 = new Wezel(10);
            var w11 = new Wezel(1);

            w1.leweDziecko = (w2);
            w1.praweDziecko = (w7);
            w7.leweDziecko = (w8);
            w7.praweDziecko = (w9);
            w2.leweDziecko = (w4);
            w4.leweDziecko = (w3);
            w8.leweDziecko = (w5);
            w8.praweDziecko = (w10);
            w3.leweDziecko = (w11);
            w6.leweDziecko = (w3);
            A(w1, 8);

        }



        void A(Wezel w, int szukanaWartosc)
        {
            if(szukanaWartosc == w.wartosc)
            {
                MessageBox.Show("Szukana wartosc " + w.wartosc.ToString());
            }


            if(w.leweDziecko!= null && szukanaWartosc < w.wartosc)
            {
                A(w.leweDziecko, szukanaWartosc);
            } else if(w.praweDziecko != null && szukanaWartosc >= w.wartosc)
            {
                A(w.praweDziecko, szukanaWartosc);
            }

        }
    }



    public class Wezel
    {
        public int wartosc;
        public Wezel leweDziecko;
        public Wezel praweDziecko;

        public Wezel(int wartosc)
        {
            this.wartosc = wartosc;
        }
    }


}