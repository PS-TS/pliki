namespace lab5
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            var w1 = new Wezel(1);
            var w2 = new Wezel(2);
            var w3 = new Wezel(3);
            var w4 = new Wezel(4);
            var w5 = new Wezel(5);
            var w6 = new Wezel(7);
            w1.dzieci.Add(w2);
            w1.dzieci.Add(w3);
            w1.dzieci.Add(w6);
            w2.dzieci.Add(w4);
            w2.dzieci.Add(w5);
            A(w1);

        }


        void A(Wezel w)
        {
            foreach(var element in w.dzieci)
            {
                MessageBox.Show(element.wartosc.ToString());
                A(element);
            }
        }
    }


    public class Wezel
    {
        public int wartosc;
        public List<Wezel> dzieci = new List<Wezel>();


        public Wezel(int liczba)
        {
            this.wartosc = liczba;
        }
    }
}