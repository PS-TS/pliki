package zad1;

public class TestProduct {
    public static void main(String[] args){
        Product product = new Product(-401,"Władek");
        Product product2 = new Product(401,"Władek");
        System.out.println(product.value());
        System.out.println(product.isExpensive());
        System.out.println(product2.isExpensive());
    }
}
