package zad1;

public record Product(double value,String name) {
    public Product(double value,String name){
        if(value <0){
            this.value = 1;
        }
        else this.value = value;
        this.name = name;
    }
    public boolean isExpensive(){
        if(value>400){
            return true;
        }
        else return false;
    }
}
