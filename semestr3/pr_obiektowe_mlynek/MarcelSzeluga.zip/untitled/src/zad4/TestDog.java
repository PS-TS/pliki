package zad4;

public class TestDog {
    public static void main(String[] args){
        Dog dog = new Dog("Burek",20);
    }
}
