package zad4;

public class Dog implements Cloneable {
    String breeed;
    double age;
    public Dog(String breeed, int age){
        this.breeed = breeed;
        this.age = age;
    }
}
