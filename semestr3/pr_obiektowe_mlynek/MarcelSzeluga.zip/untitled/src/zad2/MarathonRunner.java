package zad2;

public class MarathonRunner {
    String name;
    int raceTime;
    public MarathonRunner(String name, int raceTime){
        this.name = name;
        this.raceTime = raceTime;
    }
    public int getRaceTime(){
        return raceTime;
    }
    @Override
    public String toString(){
        return "imie " + name + " Czas " + raceTime;
    }
}
