package zad2;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class TestMarathonRunner {
    public static void main(String[] args){
        List<MarathonRunner> lista = new ArrayList<>();
        lista.add(new MarathonRunner("Władek",20));
        lista.add(new MarathonRunner("Sławek",30));
        lista.add(new MarathonRunner("Ignacy",40));
        Collections.sort(lista,new TestowyComparator());
        for(MarathonRunner e : lista){
            System.out.println(lista);
        }
    }
}
