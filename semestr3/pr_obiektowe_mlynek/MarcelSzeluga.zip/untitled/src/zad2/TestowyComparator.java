package zad2;

import java.util.Comparator;

public class TestowyComparator implements Comparator<MarathonRunner> {

    @Override
    public int compare(MarathonRunner o1, MarathonRunner o2) {
        if(o1.getRaceTime()>o2.getRaceTime()) {
            return Integer.compare(o1.raceTime, o2.raceTime);
        }
        else return Integer.compare(o2.raceTime, o1.raceTime);
    }
}
