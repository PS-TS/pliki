package zad3;

public class TestDrinkable {
    public static void main(String[] args){
        Drinkable Water = new Water();
        Drinkable OrangeJuice = new OrangeJuice();
        Water.drink();
        OrangeJuice.drink();
    }
}
