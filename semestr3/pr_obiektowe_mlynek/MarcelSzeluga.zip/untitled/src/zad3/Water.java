package zad3;

public class Water implements Drinkable{
    @Override
    public void drink() {
        System.out.println("Pijesz wode");
    }
}
