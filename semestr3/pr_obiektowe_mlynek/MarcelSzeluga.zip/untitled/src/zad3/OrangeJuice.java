package zad3;

public class OrangeJuice implements Drinkable{
    @Override
    public void drink() {
        System.out.println("Pijesz sok pomaranczowy");
    }
}
