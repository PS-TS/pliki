package zad3;

public interface Drinkable {
    public abstract void drink();
}
