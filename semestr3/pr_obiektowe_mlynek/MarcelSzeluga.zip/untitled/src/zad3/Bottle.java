package zad3;


public class Bottle implements Drinkable {
    private Bottle bottle;
    public Bottle(Bottle bottle){
        this.bottle = bottle;
    }

    @Override
    public void drink() {
        bottle.drink();
    }
}
