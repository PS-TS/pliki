package zadd3;

public class ziemniak implements Consumable{

    @Override
    public void Consume() {
        System.out.println("to nie frytka");
    }
}
