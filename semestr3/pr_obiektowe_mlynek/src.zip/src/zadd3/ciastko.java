package zadd3;

public class ciastko implements Consumable{
    @Override
    public void Consume() {
       System.out.println("100 kalorii");
    }
}
