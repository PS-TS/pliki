package zadd3;

public class Test {

    public static void main(String[] args){

        Consumable ciastko = new ciastko();
        Consumable ziemniak = new ziemniak();
        Przekonski Snack = new Przekonski(ciastko);
        Przekonski Snack1 = new Przekonski(ziemniak);
        Snack.HaveSnack();
        Snack1.HaveSnack();
    }
}
