package zadd3;

import jdk.jshell.Snippet;

public class Przekonski {
    private Consumable paczka;//pole typu
    public void HaveSnack(){
        paczka.Consume();
    }

    public Przekonski(Consumable paczka) {
        this.paczka = paczka;
    }
}
