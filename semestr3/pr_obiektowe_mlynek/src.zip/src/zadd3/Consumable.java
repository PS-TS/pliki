package zadd3;

public interface Consumable {

  public abstract void Consume();


}
