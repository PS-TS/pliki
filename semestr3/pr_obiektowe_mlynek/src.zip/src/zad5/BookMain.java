package zad5;

public class BookMain {
    public static void main(String[] args){
        Book book = new Book("sie","ma");
        printObjectInfo(book);
    }
    public static <T extends Object> void printObjectInfo(T nazwa){
        System.out.println(nazwa.getClass());
        System.out.println(nazwa.toString());
        System.out.println(nazwa.hashCode());
    }
}
