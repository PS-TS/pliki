package zad2;

public class Employee {
     private String name;
     private int salary;
     private int czasPracy;

    public Employee(String name, int salary, int czasPracy) {
        this.name = name;
        this.salary = salary;
        this.czasPracy = czasPracy;
    }

    public int getSalary() {
        return salary;
    }

    public int getCzasPracy() {
        return czasPracy;
    }

    @Override
    public String toString() {
        return "Employee{" +
                "name='" + name + '\'' +
                ", salary=" + salary +
                ", czasPracy=" + czasPracy +
                '}';
    }
}
