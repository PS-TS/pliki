package zad2;

import java.util.Comparator;

public class Employeev2 implements Comparator<Employee> {


    @Override
    public int compare(Employee o1, Employee o2) {
        if (o1.getSalary() != o2.getSalary()) {
         return Integer.compare(o1.getSalary(),o2.getSalary())*(-1);
        }
        else
            return Integer.compare(o1.getCzasPracy(),o2.getCzasPracy())*(-1);//porownywuje
    }

}

