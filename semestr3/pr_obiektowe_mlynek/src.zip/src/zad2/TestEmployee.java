package zad2;
import java.util.Collection;
import java.util.List;
import java.util.ArrayList;
import java.util.Collections;
public class TestEmployee {
    public static void main(String[] args)
    {
        List<Employee> praca= new ArrayList<>();
        praca.add(new Employee("stas",100,5));
        praca.add(new Employee("marek",45,1));
        praca.add(new Employee("Jacek",1,3));


        Collections.sort(praca,new Employeev2());
        for(Employee e:praca)//sortuje elementy listy
        {
            System.out.println(e);
        }

    }
}
