package zad1;

public record House(String street, int homeNumber,int inhabitants) {
    public House(String street, int homeNumber, int inhabitants) {
        this.street = street;
        this.homeNumber = homeNumber;
        if (inhabitants < 0) {
            this.inhabitants = 0;
        } else {
            this.inhabitants = inhabitants;
        }

    }

    public void ringDoorbell() {
        if (inhabitants > 0) {
            System.out.println("Kto tam?");
        }
        else
        {
            System.out.println("Nikogo nie ma");
        }
    }
}
