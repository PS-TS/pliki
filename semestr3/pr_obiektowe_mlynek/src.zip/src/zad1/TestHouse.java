package zad1;

import java.util.HashMap;

public class TestHouse {

    public static void main(String[] args)
    {
        House dom=new House("sezamowa",10,5);
        House dom1=new House("sezamowa",10,-9);
        dom.ringDoorbell();
        dom1.ringDoorbell();
    }
}
