package zad4;

public class ValueTooLowException extends Exception{

}
