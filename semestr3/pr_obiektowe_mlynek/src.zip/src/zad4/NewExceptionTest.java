package zad4;

import java.util.Scanner;

public class NewExceptionTest {
    public static void main(String[] args){
        Scanner scanner = new Scanner(System.in);
        double liczba = scanner.nextDouble();

        try{
            double[] tablica = GetFilledArray(liczba);
        }catch (ValueTooLowException e){

        }
    }
    public static double[] GetFilledArray(double value) throws ValueTooLowException {

        if(value<1)
        {
            throw new ValueTooLowException();
        }
        double[] tablica2 = new double[10];
        for(int i=0;i<tablica2.length;i++)
        {
            tablica2[i]=value;
        }
        return tablica2;
    }
}
