import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

df = pd.read_excel('turystyka1.xlsx')
df = df.transpose()

df['kategorie'] = df.index


r2014 = df[df[0] == 2014]
print(r2014)
r2014 = r2014[1].values
r2015 = df[df[0] == 2015]
print(r2015)
r2015 = r2015[1].values

kategorie = df['kategorie'].drop_duplicates()


plt.plot(['*****', '****', '***', '**', '*'],r2014, label='2014')
plt.plot(['*****', '****', '***', '**', '*'],r2015, label='2015')
plt.xlabel('Gwiazdki')
plt.ylabel('Liczba turystów')
plt.legend()
plt.title('Liczba turystów z podziałem na kategorie w latach 2014 i 2015')

plt.show()

