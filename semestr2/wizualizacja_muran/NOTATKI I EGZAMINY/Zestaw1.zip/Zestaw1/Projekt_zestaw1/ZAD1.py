import matplotlib.pyplot as plt

wartosci = [19, 32, 9, 16, 24]
etykiety = ['A', 'B', 'C', 'D', 'E']
explode = (0.2, 0, 0, 0, 0)
colors = ['purple', 'deeppink', 'orchid', 'green', 'grey']

plt.subplot(1,2,1)
plt.pie(wartosci, explode = explode, labels = etykiety, colors = colors,
autopct = '%1.f%%', shadow = True)
plt.title('Tytul1')


wartosci = [88, 84, 94, 77, 90]
etykiety = [88, 84, 94, 77, 90]
explode = (0.2, 0, 0, 0, 0)
colors = ['cyan', 'darkgreen', 'lightgreen', 'purple', 'orchid']

plt.subplot(1,2,2)
plt.pie(wartosci, explode = explode, labels = etykiety, colors = colors, shadow = True)
plt.title('Tytul2')
plt.show()