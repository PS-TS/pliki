import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

df = pd.read_excel('mieszkania1.xlsx')

rok = np.unique(df['Rok'].values)

indywidualne = df[(df['Formy budownictwa'] == 'indywidualne')]
indywidualne = indywidualne['Wartość'].values

spoldzielcze = df[(df['Formy budownictwa'] == 'spółdzielcze')]
spoldzielcze = spoldzielcze['Wartość'].values

komunalne = df[(df['Formy budownictwa'] == 'komunalne')]
komunalne = komunalne['Wartość'].values

X = np.arange(4)

plt.bar(X + 0.00, indywidualne, color='blue', width=0.25, label='indywidualne')
plt.bar(X + 0.25, spoldzielcze, color='green', width=0.25, label='spółdzielcze')
plt.bar(X + 0.50, komunalne, color='red', width=0.25, label='komunalne')
labelsbar = [2015, 2016, 2017, 2018]
plt.xticks(X + 0.25, rok)
plt.legend()
plt.show()





