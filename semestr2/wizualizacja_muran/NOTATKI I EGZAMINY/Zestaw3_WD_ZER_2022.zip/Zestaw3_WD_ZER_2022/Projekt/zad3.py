import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

df = odczyt = pd.read_csv('sport3.csv', delimiter=';')
wojewodztwa = df[(df['Nazwa'] == 'WARMIŃSKO-MAZURSKIE') | (df['Nazwa'] == 'POMORSKIE')]

wartosc_pom = wojewodztwa[wojewodztwa['Nazwa'] == 'POMORSKIE']['Wartość'].values
wartosc_warm = wojewodztwa[wojewodztwa['Nazwa'] == 'WARMIŃSKO-MAZURSKIE']['Wartość'].values
x = wojewodztwa[wojewodztwa['Nazwa'] == 'WARMIŃSKO-MAZURSKIE']['Gry zespołowe'].values
Z = np.arange(4)

plt.bar(Z + 0.00, wartosc_pom, color='b', width=0.25, label='Pomorskie')
plt.bar(Z + 0.25, wartosc_warm, color='g', width=0.25, label='Warmińsko-Mazurskie')
labelsbar = ['WARMIŃSKO-MAZURSKIE', 'POMORSKIE']
plt.xticks(Z + 0.25, x)
plt.legend()

plt.show()
