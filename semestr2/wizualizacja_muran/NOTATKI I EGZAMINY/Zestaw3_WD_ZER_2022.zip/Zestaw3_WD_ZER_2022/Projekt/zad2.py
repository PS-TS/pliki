import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
df = pd.read_excel('ceny3.xlsx')

x = df['Rok'].values
y = df['Wartość'].values
plt.plot(x, y, label='Cena ryżu')
plt.legend()
plt.title('Wartość ryżu w latach 2010-2020')
plt.xlabel('Rok')
plt.ylabel('Wartość (zł)')
plt.show()


