import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

width1 = [-14, -27, -23, -14]
width2 = [20, 22, 20, 35]
width2 = [35, 20, 22, 20]
bars1 = [32, 34, 30, 7]
bars2 = [38, 32, 37, 41]
bars2 = [41, 37, 32, 38]
colors1 = ['green', 'cyan', 'violet', 'cyan']
colors2 = ['grey', 'orange', 'red', 'pink']
x_pos = np.arange(len(bars1))

xx = np.linspace(-25,0, 6)
print(xx)
plt.subplot(1,2,1)
plt.barh(x_pos, width1, color = colors1)
plt.title('1_2')
plt.yticks(x_pos, bars1)
plt.xticks(xx)

plt.subplot(1,2,2)
plt.barh(x_pos, width2, color = colors2)
plt.title('2_2')
plt.yticks(x_pos, bars2)


plt.show()