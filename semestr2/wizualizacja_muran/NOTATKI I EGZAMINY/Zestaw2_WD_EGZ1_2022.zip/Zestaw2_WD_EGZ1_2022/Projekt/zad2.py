import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

df = pd.read_excel('produkcja2.xlsx')

x = df['Rok'].values
y = df['Wartość'].values

plt.plot(x, y, label='Wartość produukcji', color='red', linestyle='--')
plt.title('Wartość produkcji w Polsce na przełomie lat')
plt.xlabel('Rok')
plt.ylabel('Wartość (mln)')
plt.text(2, 3, '23:49')
plt.savefig('zad2_wykres.png', format='png')
plt.show()