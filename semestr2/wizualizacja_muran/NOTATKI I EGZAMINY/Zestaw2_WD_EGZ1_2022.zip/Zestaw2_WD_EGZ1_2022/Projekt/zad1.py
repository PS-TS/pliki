import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

width1 = [26, 24, 45, 17, 10, 3]
width2 = [-19, -19, -8, -38, -18, -43]
bars = ('Styczeń', 'Luty', 'Marzec', 'Kwiecień', 'Maj', 'Czerwiec')
x_pos = np.arange(len(bars))
plt.barh(bars, width1, color='cyan', label='A')
plt.barh(bars, width2, color='red', label='B')
plt.title('Wykres zmian A i B')
plt.legend()
plt.show()