import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

plt.subplot(2,1,1)

df = pd.read_csv('sport2.csv', delimiter='#')
kobiety = df[df['Płeć'] == 'K']
popularnosc_k = kobiety['Popularność'].values
mezczyzni = df[df['Płeć'] == 'M']
popularnosc_m = mezczyzni['Popularność'].values

labels = ['Piłka nożna', 'Koszykówka', 'Siatkówka', 'Inne']
colors = ['red', 'green', 'blue', 'pink']
explode = (0, 0.1, 0, 0)

plt.pie(popularnosc_k, explode = explode, labels = labels, colors = colors)
plt.title('Kobiety')

plt.subplot(2,1,2)
plt.pie(popularnosc_m, explode = explode, labels = labels, colors = colors)
plt.title('Mężczyźni')

plt.show()